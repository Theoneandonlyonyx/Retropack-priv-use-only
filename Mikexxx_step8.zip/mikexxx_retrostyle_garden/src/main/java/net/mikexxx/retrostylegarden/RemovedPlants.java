package net.mikexxx.retrostylegarden;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.MissingMappingsEvent;

/**
 * Old ids from earlier versions of the mod.
 * removed_plants.txt: ids that no longer exist - they vanish silently (blocks become air, stacks disappear).
 * merged_plants.txt: "old new" - plants that were merged or renamed; old worlds / inventories get the new plant.
 */
public final class RemovedPlants {
    private static final Set<String> IDS = new HashSet<>();
    private static final Map<String, String> MERGED = new HashMap<>();

    static {
        for (String line : read("/removed_plants.txt")) {
            IDS.add(line);
        }
        for (String line : read("/merged_plants.txt")) {
            String[] p = line.split("\\s+");
            if (p.length == 2) {
                MERGED.put(p[0], p[1]);
            }
        }
    }

    private RemovedPlants() {
    }

    private static Set<String> read(String resource) {
        Set<String> out = new java.util.LinkedHashSet<>();
        try (InputStream in = RemovedPlants.class.getResourceAsStream(resource)) {
            if (in == null) {
                return out;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    out.add(line);
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return out;
    }

    public static void onMissingMappings(MissingMappingsEvent event) {
        for (MissingMappingsEvent.Mapping<Block> mapping : event.getMappings(ForgeRegistries.Keys.BLOCKS, RetrostyleGarden.MODID)) {
            String path = mapping.getKey().getPath();
            String target = MERGED.get(path);
            if (target != null) {
                Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(RetrostyleGarden.MODID, target));
                if (block != null && block != Blocks.AIR) {
                    mapping.remap(block);
                } else {
                    mapping.ignore();
                }
            } else if (IDS.contains(path)) {
                mapping.ignore();
            }
        }
        for (MissingMappingsEvent.Mapping<Item> mapping : event.getMappings(ForgeRegistries.Keys.ITEMS, RetrostyleGarden.MODID)) {
            String path = mapping.getKey().getPath();
            String target = MERGED.get(path);
            if (target != null) {
                Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(RetrostyleGarden.MODID, target));
                if (item != null && item != Items.AIR) {
                    mapping.remap(item);
                } else {
                    mapping.ignore();
                }
            } else if (IDS.contains(path)) {
                mapping.ignore();
            }
        }
    }
}
