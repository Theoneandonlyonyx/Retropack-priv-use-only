# Mikexxx Retrostyle Garden  (Forge 1.20.1)

574 decorative plant blocks (plus the space blocks and a cake) built from your retro texture pack:
flowers, tulips, ferns, tall grass, shrubs, saplings, mushrooms, vines, ivy, lily pads, cacti, sunflowers,
cattails, leaf piles ... including all the "alternate" textures. Every block has an English and a German name
(`en_us.json` / `de_de.json`). Full list: **BLOCK_LIST.md**. Everything is in one creative tab.

## Build (needs JDK 17 and internet for the first build)
    ./gradlew build          (Windows: gradlew.bat build)
The finished mod is `build/libs/mikexxx_retrostyle_garden-1.0.0.jar` -> put it in your `mods` folder
(Minecraft 1.20.1, Forge 47.x, e.g. 47.3.0).  Test from the project: `./gradlew runClient`.

## Shapes
| shape | used for |
|---|---|
| cross | flowers, ferns, small grass, shrubs, saplings, mushrooms |
| crop (#-shaped) | lawns, hay, grain, tulip groups, flower fields/patches |
| tall (2 blocks) | tall grass, large ferns, rose bushes, lilac, tall bushes |
| sunflower | 2 blocks with a real flower head that faces east |
| lily | lily pads lie flat on water |
| bloom | **water lily blossoms** - items you right-click onto one of this mod's lily pads; they stand upright on the pad as crossed planes and drop again when the pad is broken |
| vine | vines / ivy / ladders that climb walls (and are climbable) |
| cactus | real cactus: needs sand, hurts, inset sides, flowering tops |
| flat | leaf piles & flower scatter lying on the ground |
| cube | the two flowering foliage blocks |

## Stackable
All cacti, tall cacti, canes (bamboo, grape, vine cane), corn stalks, tall cattails, grapevines, topiary and
sunflower stalks can be placed on top of themselves and on each other (cacti on cacti, tall cactus on cactus, ...).
They still need sand/dirt at the bottom of the pile.

## Space blocks - crafting
Shaped, gives 1 block:

    C M C        C = coal block (vanilla)
    M X M        M = the gem / bar / shard of the block (gold ingot, diamond, emerald, amethyst shard, ...)
    C M C        X = coal block  (BLACK versions)   or   1 purple dye  (VIOLET / PURPLE versions)

Sapphire and topaz have no vanilla item, so they use the tags `forge:gems/sapphire` / `forge:gems/topaz`
(any mod that adds those gems works).

## Dyes from flowers
Every flower can be crafted (alone) into the dye of its colour - 1 dye for small flowers, 2 for tall ones.
**Multicolour flowers** (tulip mix, tricolor mixes, wildflowers, marigold, mixed sunflowers ...) give ONE of their
dyes depending on the slot you put them in: colour number = (column + row) mod (number of colours), counted from
the top-left, first colour = the first one listed in BLOCK_LIST.md.
Example, red-blue mix: slots 1,3,5,7,9 -> red, slots 2,4,6,8 -> blue.

## Natural generation (all data driven, see data/mikexxx_retrostyle_garden/worldgen and forge/biome_modifier)
Plants generate in patches in the biomes they belong to, e.g.
* jungle: ginger, hibiscus, tropical flowers, bamboo cane, pineapple, ferns, jungle/cocoa saplings
* swamp: lily pads (sometimes with pink / white blossoms), cattails, roots, orchids, mushrooms
* desert / badlands: all cacti, dead bushes, wasteland scrub, desert lotus
* plains / meadow / cherry grove: tulips, poppies, wildflowers, sunflowers, pink flowers
* forest / taiga / snowy: ferns, violets, autumn shrubs, leaf piles, pines & firs, poinsettia, mushrooms
* savanna: hay, grain, golden roses, acacia saplings; mountains: ridge scrub, star flowers
Not generated: vines (they only grow where you put them), space blocks, cake, topiary.

## Credits
The textures come from the pack you supplied - please check that pack's licence before you publish the mod.
