package net.mikexxx.retrostylegarden;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.WaterlilyBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;

/**
 * Lily pad of this mod. Water lily blossoms can only be placed on these pads
 * (they are a block state, so they stand upright on the pad as crossed planes).
 */
public class RetroLilyPadBlock extends WaterlilyBlock {
    public static final EnumProperty<Bloom> BLOOM = EnumProperty.create("bloom", Bloom.class);

    public RetroLilyPadBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(BLOOM, Bloom.NONE));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(BLOOM);
    }
}
