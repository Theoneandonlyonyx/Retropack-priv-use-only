package net.mikexxx.retrostylegarden;

import net.minecraft.client.color.block.BlockColor;
import net.minecraft.client.color.item.ItemColor;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.world.level.FoliageColor;
import net.minecraft.world.level.GrassColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Biome tinting for the grey (tintable) textures: grass, foliage and lily pads. */
@Mod.EventBusSubscriber(modid = RetrostyleGarden.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {
    }

    private static final BlockColor GRASS_BLOCK = (state, level, pos, index) ->
            level != null && pos != null ? BiomeColors.getAverageGrassColor(level, pos) : GrassColor.get(0.5D, 1.0D);
    private static final BlockColor FOLIAGE_BLOCK = (state, level, pos, index) ->
            level != null && pos != null ? BiomeColors.getAverageFoliageColor(level, pos) : FoliageColor.getDefaultColor();
    private static final BlockColor LILY_BLOCK = (state, level, pos, index) ->
            level != null && pos != null ? 2129968 : 7455580;

    private static final ItemColor GRASS_ITEM = (stack, index) -> GrassColor.get(0.5D, 1.0D);
    private static final ItemColor FOLIAGE_ITEM = (stack, index) -> FoliageColor.getDefaultColor();
    private static final ItemColor LILY_ITEM = (stack, index) -> 7455580;

    @SubscribeEvent
    public static void registerBlockColors(RegisterColorHandlersEvent.Block event) {
        for (PlantDef def : RetrostyleGarden.DEFS) {
            BlockColor color = switch (def.tint()) {
                case 'g' -> GRASS_BLOCK;
                case 'f' -> FOLIAGE_BLOCK;
                case 'l' -> LILY_BLOCK;
                default -> null;
            };
            if (color != null) {
                event.register(color, RetrostyleGarden.BLOCK_BY_ID.get(def.id()).get());
            }
        }
    }

    @SubscribeEvent
    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        for (PlantDef def : RetrostyleGarden.DEFS) {
            ItemColor color = switch (def.tint()) {
                case 'g' -> GRASS_ITEM;
                case 'f' -> FOLIAGE_ITEM;
                case 'l' -> LILY_ITEM;
                default -> null;
            };
            if (color != null) {
                event.register(color, RetrostyleGarden.ITEM_BY_ID.get(def.id()).get());
            }
        }
    }
}
