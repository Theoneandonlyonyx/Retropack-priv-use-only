package net.mikexxx.retrostylegarden;

import net.minecraft.util.StringRepresentable;

/** Which water lily blossom (if any) is standing on a lily pad. */
public enum Bloom implements StringRepresentable {
    NONE("none"),
    PINK("pink"),
    WHITE("white");

    private final String name;

    Bloom(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }

    public static Bloom fromItemId(String id) {
        return id.startsWith("pink") ? PINK : WHITE;
    }
}
