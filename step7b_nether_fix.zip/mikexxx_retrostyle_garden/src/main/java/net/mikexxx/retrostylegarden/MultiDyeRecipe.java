package net.mikexxx.retrostylegarden;

import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * One multicolour flower alone in the grid -> one of its dyes, chosen by the slot it lies in:
 * colour index = (column + row) mod number-of-colours.
 */
public class MultiDyeRecipe extends CustomRecipe {
    public MultiDyeRecipe(ResourceLocation id, CraftingBookCategory category) {
        super(id, category);
    }

    private ItemStack result(CraftingContainer container) {
        int slot = -1;
        for (int i = 0; i < container.getContainerSize(); i++) {
            if (!container.getItem(i).isEmpty()) {
                if (slot != -1) {
                    return ItemStack.EMPTY;
                }
                slot = i;
            }
        }
        if (slot == -1) {
            return ItemStack.EMPTY;
        }
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(container.getItem(slot).getItem());
        if (key == null || !key.getNamespace().equals(RetrostyleGarden.MODID)) {
            return ItemStack.EMPTY;
        }
        String[] dyes = MultiDyeData.DYES.get(key.getPath());
        if (dyes == null) {
            return ItemStack.EMPTY;
        }
        int width = Math.max(1, container.getWidth());
        int index = (slot % width + slot / width) % dyes.length;
        Item dye = ForgeRegistries.ITEMS.getValue(new ResourceLocation("minecraft", dyes[index]));
        return dye == null ? ItemStack.EMPTY : new ItemStack(dye);
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        return !result(container).isEmpty();
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess registryAccess) {
        return result(container);
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width * height >= 1;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.MULTI_DYE.get();
    }
}
