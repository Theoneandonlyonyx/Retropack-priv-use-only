package net.mikexxx.retrostylegarden;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Water lily blossom: right-click one of this mod's lily pads to put it on. */
public class LilyBloomItem extends Item {
    private final Bloom bloom;

    public LilyBloomItem(Properties properties, Bloom bloom) {
        super(properties);
        this.bloom = bloom;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof RetroLilyPadBlock && state.getValue(RetroLilyPadBlock.BLOOM) == Bloom.NONE) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(RetroLilyPadBlock.BLOOM, bloom), 3);
                level.playSound(null, pos, SoundEvents.GRASS_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
                Player player = context.getPlayer();
                if (player == null || !player.getAbilities().instabuild) {
                    context.getItemInHand().shrink(1);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
