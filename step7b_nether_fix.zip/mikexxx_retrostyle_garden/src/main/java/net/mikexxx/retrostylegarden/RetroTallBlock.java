package net.mikexxx.retrostylegarden;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Two block high plant (tall grass, large ferns, rose bushes, sunflowers ...). Stackable ones can be piled up. */
public class RetroTallBlock extends DoublePlantBlock implements Stackable {
    private static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);
    private final boolean stackable;

    public RetroTallBlock(Properties properties, boolean stackable) {
        super(properties);
        this.stackable = stackable;
    }

    @Override
    public boolean isStackable() {
        return stackable;
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (stackable && state.getBlock() instanceof Stackable other && other.isStackable()) {
            return true;
        }
        return state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(BlockTags.TERRACOTTA)
                || state.is(Blocks.FARMLAND) || state.is(Blocks.GRAVEL);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        Vec3 offset = state.getOffset(level, pos);
        return SHAPE.move(offset.x, offset.y, offset.z);
    }
}
