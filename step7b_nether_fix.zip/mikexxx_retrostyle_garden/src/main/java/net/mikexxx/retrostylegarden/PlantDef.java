package net.mikexxx.retrostylegarden;

/**
 * One entry of mikexxx_plants.txt.
 *
 * @param stack true = may be stacked on top of itself / other stackable plants (cane, cactus ...)
 */
public record PlantDef(String id, String kind, char tint, boolean stack) {
}
