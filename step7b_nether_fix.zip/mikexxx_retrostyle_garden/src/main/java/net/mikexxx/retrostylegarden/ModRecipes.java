package net.mikexxx.retrostylegarden;

import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.SimpleCraftingRecipeSerializer;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRecipes {
    private ModRecipes() {
    }

    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, RetrostyleGarden.MODID);

    public static final RegistryObject<RecipeSerializer<MultiDyeRecipe>> MULTI_DYE =
            SERIALIZERS.register("multi_dye", () -> new SimpleCraftingRecipeSerializer<>(MultiDyeRecipe::new));
}
