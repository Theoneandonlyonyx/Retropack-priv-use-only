package net.mikexxx.retrostylegarden;

/** Marker for blocks that other stackable plants (cane, cactus, stalks ...) may be placed on. */
public interface Stackable {
    boolean isStackable();
}
