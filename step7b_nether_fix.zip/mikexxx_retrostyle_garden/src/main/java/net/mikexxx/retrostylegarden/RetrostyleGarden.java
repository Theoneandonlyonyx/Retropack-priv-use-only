package net.mikexxx.retrostylegarden;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(RetrostyleGarden.MODID)
public class RetrostyleGarden {
    public static final String MODID = "mikexxx_retrostyle_garden";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final List<PlantDef> DEFS = PlantTable.load();
    /** Only entries that really are blocks (blossoms are items only). */
    public static final Map<String, RegistryObject<Block>> BLOCK_BY_ID = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Item>> ITEM_BY_ID = new LinkedHashMap<>();

    static {
        for (PlantDef def : DEFS) {
            if (def.kind().equals("bloom")) {
                ITEM_BY_ID.put(def.id(), ITEMS.register(def.id(), () -> PlantFactory.createBloomItem(def)));
                continue;
            }
            RegistryObject<Block> block = BLOCKS.register(def.id(), () -> PlantFactory.createBlock(def));
            RegistryObject<Item> item = ITEMS.register(def.id(), () -> PlantFactory.createItem(def, block.get()));
            BLOCK_BY_ID.put(def.id(), block);
            ITEM_BY_ID.put(def.id(), item);
        }
    }

    public static final RegistryObject<CreativeModeTab> GARDEN_TAB = TABS.register("garden", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> new ItemStack(ITEM_BY_ID.get("retro_dandelion").get()))
                    .displayItems((parameters, output) -> {
                        for (RegistryObject<Item> item : ITEM_BY_ID.values()) {
                            output.accept(item.get());
                        }
                    })
                    .build());

    public RetrostyleGarden() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        ModRecipes.SERIALIZERS.register(bus);
    }
}
