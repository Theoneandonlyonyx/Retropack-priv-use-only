package net.mikexxx.retrostylegarden;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Small decorative plant: flowers, grass, ferns, shrubs, mushrooms, ground cover ... */
public class RetroPlantBlock extends BushBlock implements Stackable {
    private final VoxelShape shape;
    private final boolean stackable;

    public RetroPlantBlock(Properties properties, VoxelShape shape, boolean stackable) {
        super(properties);
        this.shape = shape;
        this.stackable = stackable;
    }

    @Override
    public boolean isStackable() {
        return stackable;
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (stackable && state.getBlock() instanceof Stackable other && other.isStackable()) {
            return true;
        }
        return state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(BlockTags.TERRACOTTA)
                || state.is(Blocks.FARMLAND) || state.is(Blocks.GRAVEL);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        Vec3 offset = state.getOffset(level, pos);
        return shape.move(offset.x, offset.y, offset.z);
    }
}
