package net.mikexxx.retrostylegarden;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Mushroom ground rule. Players can place mushrooms in any light on any solid block.
 * Natural generation (world gen) needs darkness: no open sky above (caves, under trees / canopy),
 * except on mycelium / podzol, which always works like in vanilla.
 */
public final class MushroomRules {
    private MushroomRules() {
    }

    public static boolean canGrow(LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        BlockState ground = level.getBlockState(below);
        if (ground.is(BlockTags.MUSHROOM_GROW_BLOCK)) {
            return true;
        }
        if (!ground.isSolidRender(level, below)) {
            return false;
        }
        if (level instanceof WorldGenRegion) {
            return !level.canSeeSky(pos);
        }
        return true;
    }
}
