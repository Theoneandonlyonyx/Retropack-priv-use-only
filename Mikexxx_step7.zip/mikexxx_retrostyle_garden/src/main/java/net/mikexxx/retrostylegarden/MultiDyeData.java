package net.mikexxx.retrostylegarden;

import java.util.Map;

/**
 * Multicolour flowers and the dyes they give. Put ONE of them alone in the crafting grid:
 * the dye depends on the slot (column + row, counted from the top-left) modulo the number of colours.
 */
public final class MultiDyeData {
    private MultiDyeData() {
    }

    /** Several flowers in one block: this many dyes (a single flower gives 1, two-block-high flowers give 2). */
    public static final Map<String, Integer> BUNCH_COUNT = Map.of("tulip", 3);

    public static final Map<String, String[]> DYES = Map.ofEntries(
            Map.entry("large_tricolor_flower_mix", new String[]{"red_dye", "yellow_dye", "blue_dye"}),
            Map.entry("large_wildflowers", new String[]{"pink_dye", "white_dye", "light_blue_dye"}),
            Map.entry("low_wildflowers", new String[]{"pink_dye", "white_dye", "light_blue_dye"}),
            Map.entry("leaf_pile_with_wildflowers", new String[]{"pink_dye", "white_dye", "light_blue_dye"}),
            Map.entry("marigold", new String[]{"orange_dye", "yellow_dye"}),
            Map.entry("medium_tricolor_flower_mix", new String[]{"red_dye", "yellow_dye", "blue_dye"}),
            Map.entry("mixed_sunflower_cluster", new String[]{"yellow_dye", "red_dye", "white_dye"}),
            Map.entry("mixed_sunflower_stalks", new String[]{"yellow_dye", "red_dye", "white_dye"}),
            Map.entry("red_blue_flower_mix", new String[]{"red_dye", "blue_dye"}),
            Map.entry("red_yellow_flower_mix", new String[]{"red_dye", "yellow_dye"}),
            Map.entry("simple_wildflowers", new String[]{"pink_dye", "white_dye", "light_blue_dye"}),
            Map.entry("small_tricolor_flower_mix", new String[]{"red_dye", "yellow_dye", "blue_dye"}),
            Map.entry("small_wildflowers", new String[]{"pink_dye", "white_dye", "light_blue_dye"}),
            Map.entry("tall_tricolor_flower_mix", new String[]{"red_dye", "yellow_dye", "blue_dye"}),
            Map.entry("tulip", new String[]{"red_dye", "yellow_dye"}),
            Map.entry("wildflower_scatter", new String[]{"pink_dye", "white_dye", "light_blue_dye"}),
            Map.entry("yellow_blue_flower_mix", new String[]{"yellow_dye", "blue_dye"})
    );
}
