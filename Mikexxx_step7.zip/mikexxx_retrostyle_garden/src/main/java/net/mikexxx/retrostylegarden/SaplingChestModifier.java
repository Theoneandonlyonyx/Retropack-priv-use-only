package net.mikexxx.retrostylegarden;

import java.util.function.Supplier;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Saplings do not generate in the world any more: they only turn up as loot in generated chests
 * (dungeons, mineshafts, villages, temples, mansions ...). Not in nether / end / ruined-portal chests.
 */
public class SaplingChestModifier extends LootModifier {
    public static final Supplier<Codec<SaplingChestModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, SaplingChestModifier::new)));

    private static final TagKey<Item> SAPLINGS = TagKey.create(Registries.ITEM, new ResourceLocation(RetrostyleGarden.MODID, "saplings"));
    private static final float CHANCE = 0.3F;

    public SaplingChestModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
        ResourceLocation table = context.getQueriedLootTableId();
        String path = table.getPath();
        if (!path.startsWith("chests/") || path.contains("nether") || path.contains("bastion") || path.contains("end_city")
                || path.contains("ruined_portal") || path.contains("ancient_city") || path.contains("trial")) {
            return loot;
        }
        if (context.getRandom().nextFloat() >= CHANCE) {
            return loot;
        }
        ForgeRegistries.ITEMS.tags().getTag(SAPLINGS).getRandomElement(context.getRandom())
                .ifPresent(item -> loot.add(new ItemStack(item, 1 + context.getRandom().nextInt(2))));
        return loot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
