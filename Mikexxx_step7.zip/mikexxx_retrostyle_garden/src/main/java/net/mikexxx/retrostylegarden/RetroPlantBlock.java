package net.mikexxx.retrostylegarden;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Small decorative plant: flowers, grass, ferns, shrubs, mushrooms, ground cover ... */
public class RetroPlantBlock extends BushBlock implements Stackable {
    private final VoxelShape shape;
    private final boolean stackable;
    private final boolean mushroom;
    private final boolean wilted;

    public RetroPlantBlock(Properties properties, VoxelShape shape, boolean stackable, boolean mushroom, boolean wilted) {
        super(properties);
        this.shape = shape;
        this.stackable = stackable;
        this.mushroom = mushroom;
        this.wilted = wilted;
    }

    /**
     * Mushrooms can be placed in any light: mycelium / podzol or any full solid block is fine as ground.
     * (Natural generation is limited by the biome features, not by the light level.)
     */
    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        if (!mushroom) {
            return super.canSurvive(state, level, pos);
        }
        return MushroomRules.canGrow(level, pos);
    }

    @Override
    public boolean isStackable() {
        return stackable;
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (stackable && state.getBlock() instanceof Stackable other && other.isStackable()) {
            return true;
        }
        if (wilted && (state.is(BlockTags.BASE_STONE_OVERWORLD) || state.is(Blocks.DEEPSLATE)
                || state.is(Blocks.BLACKSTONE) || state.is(Blocks.BASALT) || state.is(Blocks.MAGMA_BLOCK))) {
            return true;
        }
        return state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(BlockTags.TERRACOTTA)
                || state.is(Blocks.FARMLAND) || state.is(Blocks.GRAVEL)
                || state.is(BlockTags.BASE_STONE_NETHER) || state.is(BlockTags.NYLIUM)
                || state.is(BlockTags.SOUL_SPEED_BLOCKS);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        Vec3 offset = state.getOffset(level, pos);
        return shape.move(offset.x, offset.y, offset.z);
    }
}
