package net.mikexxx.retrostylegarden;

/**
 * One entry of mikexxx_plants.txt.
 *
 * @param stack    true = may be stacked on top of itself / other stackable plants (cane, cactus ...)
 * @param mushroom true = mushroom: may be placed on any solid ground in any light (no darkness needed)
 * @param wilted   true = wilted flower: may also be placed on stone / netherrack (it only generates near lava)
 * @param section  the "# --- section" heading of the plant table the entry sits under (used for composting chances)
 */
public record PlantDef(String id, String kind, char tint, boolean stack, boolean mushroom, boolean wilted, String section) {
}
