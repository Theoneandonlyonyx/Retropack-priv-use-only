package net.mikexxx.retrostylegarden;

import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.ComposterBlock;
import net.minecraftforge.registries.RegistryObject;

/** Every plant of this mod can be thrown into a composter. Chances follow the vanilla values for similar plants. */
public final class Composting {
    private Composting() {
    }

    public static void register() {
        for (PlantDef def : RetrostyleGarden.DEFS) {
            RegistryObject<Item> item = RetrostyleGarden.ITEM_BY_ID.get(def.id());
            float chance = chance(def);
            if (item != null && chance > 0.0F) {
                ComposterBlock.COMPOSTABLES.put(item.get(), chance);
            }
        }
    }

    /** 0 = not compostable (the decorative metal / gem blocks). */
    static float chance(PlantDef def) {
        if (def.kind().equals("block")) {
            return 0.0F;
        }
        if (def.kind().equals("cake")) {
            return 1.0F;
        }
        if (def.mushroom()) {
            return 0.65F;
        }
        String id = def.id();
        switch (def.kind()) {
            case "bloom":
            case "lily":
                return 0.65F;
            case "vine":
            case "cactus":
                return 0.5F;
            case "cube":
                return 0.3F;
            default:
                break;
        }
        if (id.contains("sapling") || id.contains("bonsai")) {
            return 0.3F;
        }
        String section = def.section();
        if (section.equals("Crops")) {
            return 0.65F;
        }
        boolean tall = def.kind().equals("tall") || def.kind().equals("sunflower");
        if (section.equals("Classic flowers") || section.equals("Sunflowers") || section.equals("Tulips")
                || section.equals("Flower mixes") || section.equals("Flowers")) {
            return 0.65F;
        }
        if (section.equals("Tall grass") || id.contains("large_fern") || id.contains("tall_")) {
            return 0.5F;
        }
        if (section.equals("Shrubs & bushes") || section.equals("Leaf piles")) {
            return tall ? 0.5F : 0.3F;
        }
        // grass, ferns, roots, cattails, desert scrub ...
        return tall ? 0.5F : 0.3F;
    }
}
