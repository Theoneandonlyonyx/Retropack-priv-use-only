# Mikexxx Retrostyle Garden  (Forge 1.20.1)

571 decorative plant blocks built from your retro texture pack: flowers, tulips, ferns, tall grass,
shrubs, saplings, bushes, mushrooms, vines, ivy, lily pads, cacti, sunflowers, cattails, leaf piles ...
including all the "alternate" textures. Every block has an English and a German name
(`en_us.json` / `de_de.json`). Full list: **BLOCK_LIST.md**. Everything is in one creative tab,
"Mikexxx Retrostyle Garden".

## Build (needs JDK 17 and internet for the first build)
    ./gradlew build          (Windows: gradlew.bat build)
The finished mod is `build/libs/mikexxx_retrostyle_garden-1.0.0.jar` -> put it in your `mods` folder
(Minecraft 1.20.1, Forge 47.x, e.g. 47.3.0).

Test in-game from the project:  `./gradlew runClient`
IntelliJ / Eclipse: open the folder as a Gradle project, then run `genIntellijRuns` / `genEclipseRuns`.

## Shapes (not everything is a plain cross)
| shape | used for |
|---|---|
| cross | flowers, ferns, small grass, shrubs, saplings, mushrooms, cane |
| crop (#-shaped) | lawns, hay, grain, tulip groups, flower fields/patches |
| tall (2 blocks) | tall grass, large ferns, rose bushes, lilac, topiary, tall bushes |
| sunflower | 2 blocks with a real flower head that faces east |
| lily | lily pads lie flat on water (place them on water) |
| vine | vines / ivy / ladders that climb walls (and are climbable) |
| cactus | real cactus: needs sand, hurts, inset sides, flowering tops |
| flat | leaf piles & flower scatter lying on the ground |
| cube | the two flowering leaf blocks |

* Plants can be placed on dirt/grass/podzol/moss/mud, sand, terracotta, farmland and gravel.
* Grey ("Biome ...") textures are biome tinted like vanilla grass / foliage / lily pads.
* "Retro ..." = the pack's main textures, no prefix = the alternates.

## Left out on purpose
Crops (wheat, carrots ...), pumpkins/melons, hay bales, grass-block tops, mobs/GUI/items and the
novelty ones (creeper statues, Mario items, the cat). Easy to add - tell me.

## Credits
The textures come from the pack you supplied - please check that pack's licence before you publish the mod.
