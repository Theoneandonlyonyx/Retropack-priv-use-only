# Block list - Mikexxx Retrostyle Garden

571 blocks.  Shape types: cross, crop (#-shaped), tall (2 blocks), sunflower (2 blocks + head), lily (floats on water), vine (climbs walls), cactus (sand, prickly), flat (ground cover), cube.

| English | Deutsch | Shape | id |
|---|---|---|---|
| Retro Allium | Retro-Zierlauch | cross | `retro_allium` |
| Retro Blue Orchid | Retro-Blaue Orchidee | cross | `retro_blue_orchid` |
| Retro Dandelion | Retro-Löwenzahn | cross | `retro_dandelion` |
| Retro Azure Bluet | Retro-Porzellansternchen | cross | `retro_azure_bluet` |
| Retro Oxeye Daisy | Retro-Margerite | cross | `retro_oxeye_daisy` |
| Retro Peony | Retro-Pfingstrose | cross | `retro_peony` |
| Retro Poppy | Retro-Mohn | cross | `retro_poppy` |
| Retro Orange Tulip | Retro-Orange Tulpe | cross | `retro_orange_tulip` |
| Retro Pink Tulip | Retro-Rosa Tulpe | cross | `retro_pink_tulip` |
| Retro Red Tulip | Retro-Rote Tulpe | cross | `retro_red_tulip` |
| Retro White Tulip | Retro-Weiße Tulpe | cross | `retro_white_tulip` |
| Retro Fern | Retro-Farn | cross | `retro_fern` |
| Retro Grass | Retro-Gras | cross | `retro_grass` |
| Retro Dead Bush | Retro-Toter Busch | cross | `retro_dead_bush` |
| Retro Brown Mushroom | Retro-Brauner Pilz | cross | `retro_brown_mushroom` |
| Retro Red Mushroom | Retro-Roter Pilz | cross | `retro_red_mushroom` |
| Retro Sugar Cane | Retro-Zuckerrohr | cross | `retro_sugar_cane` |
| Retro Oak Sapling | Retro-Eichensetzling | cross | `retro_oak_sapling` |
| Retro Spruce Sapling | Retro-Fichtensetzling | cross | `retro_spruce_sapling` |
| Retro Birch Sapling | Retro-Birkensetzling | cross | `retro_birch_sapling` |
| Retro Jungle Sapling | Retro-Tropenbaum-Setzling | cross | `retro_jungle_sapling` |
| Retro Acacia Sapling | Retro-Akaziensetzling | cross | `retro_acacia_sapling` |
| Retro Dark Oak Sapling | Retro-Schwarzeichensetzling | cross | `retro_dark_oak_sapling` |
| Retro Lily Pad | Retro-Seerosenblatt | lily | `retro_lily_pad` |
| Retro Vines | Retro-Ranken | vine | `retro_vines` |
| Retro Cactus | Retro-Kaktus | cactus | `retro_cactus` |
| Retro Large Fern | Retro-Großer Farn | tall | `retro_large_fern` |
| Retro Tall Grass | Retro-Hohes Gras | tall | `retro_tall_grass` |
| Retro Tall Peony | Retro-Hohe Pfingstrose | tall | `retro_tall_peony` |
| Retro Rose Bush | Retro-Rosenstrauch | tall | `retro_rose_bush` |
| Retro Lilac | Retro-Flieder | tall | `retro_lilac` |
| Retro Sunflower | Retro-Sonnenblume | sunflower | `retro_sunflower` |
| Allium | Zierlauch | cross | `allium` |
| Baby's Breath | Schleierkraut | cross | `baby_s_breath` |
| Bamboo Shoot | Bambussprössling | cross | `bamboo_shoot` |
| Beet Plant | Rote-Bete-Pflanze | cross | `beet_plant` |
| Bellflower | Glockenblume | cross | `bellflower` |
| Carrot Plant | Möhrenkraut | cross | `carrot_plant` |
| Cattail | Rohrkolben | cross | `cattail` |
| Cattail Patch | Rohrkolbenbestand | crop | `cattail_patch` |
| Chrysanthemum | Chrysantheme | cross | `chrysanthemum` |
| Daisy | Gänseblümchen | cross | `daisy` |
| Echinacea Cluster | Sonnenhutgruppe | crop | `echinacea_cluster` |
| Echinacea Field | Sonnenhutfeld | crop | `echinacea_field` |
| Low Echinacea | Niedriger Sonnenhut | cross | `low_echinacea` |
| Flax | Flachs | cross | `flax` |
| Red Ginger | Rote Ingwerlilie | cross | `red_ginger` |
| Red Ginger Patch | Rotes Ingwerlilienbeet | crop | `red_ginger_patch` |
| Dead Grass Tuft | Verdorrtes Grasbüschel | cross | `dead_grass_tuft` |
| Green Grass Tuft | Grünes Grasbüschel | cross | `green_grass_tuft` |
| Red Grass Tuft | Rotes Grasbüschel | cross | `red_grass_tuft` |
| Hibiscus | Hibiskus | cross | `hibiscus` |
| Bluet | Porzellansternchen | cross | `bluet` |
| Red-Blue Flower Mix | Rot-blauer Blumenmix | cross | `red_blue_flower_mix` |
| Red-Yellow Flower Mix | Rot-gelber Blumenmix | cross | `red_yellow_flower_mix` |
| Large Tricolor Flower Mix | Großer dreifarbiger Blumenmix | cross | `large_tricolor_flower_mix` |
| Medium Tricolor Flower Mix | Mittlerer dreifarbiger Blumenmix | cross | `medium_tricolor_flower_mix` |
| Small Tricolor Flower Mix | Kleiner dreifarbiger Blumenmix | cross | `small_tricolor_flower_mix` |
| Tall Tricolor Flower Mix | Hoher dreifarbiger Blumenmix | cross | `tall_tricolor_flower_mix` |
| Yellow-Blue Flower Mix | Gelb-blauer Blumenmix | cross | `yellow_blue_flower_mix` |
| Hydrangea | Hortensie | cross | `hydrangea` |
| Leafy Foliage | Blattwerk | cross | `leafy_foliage` |
| Marigold | Ringelblume | cross | `marigold` |
| Morning Glory Cluster | Prunkwindengruppe | crop | `morning_glory_cluster` |
| Morning Glory Field | Prunkwindenfeld | crop | `morning_glory_field` |
| Low Morning Glory | Niedrige Prunkwinde | cross | `low_morning_glory` |
| Nasturtium | Kapuzinerkresse | cross | `nasturtium` |
| Classic Nasturtium | Klassische Kapuzinerkresse | cross | `classic_nasturtium` |
| Nasturtium Cluster | Kapuzinerkressegruppe | crop | `nasturtium_cluster` |
| Low Nasturtium | Niedrige Kapuzinerkresse | cross | `low_nasturtium` |
| Nether Leaf | Netherblatt | cross | `nether_leaf` |
| Big Nether Leaf | Großes Netherblatt | cross | `big_nether_leaf` |
| Orchid | Orchidee | cross | `orchid` |
| Oxeye Daisy | Margerite | cross | `oxeye_daisy` |
| Wild Peony | Wilde Pfingstrose | cross | `wild_peony` |
| Parsley | Petersilie | cross | `parsley` |
| Peony Bloom | Päonienblüte | cross | `peony_bloom` |
| Poinsettia | Weihnachtsstern | cross | `poinsettia` |
| Poppy Patch | Mohnbeet | crop | `poppy_patch` |
| Simple Poppy | Schlichter Mohn | cross | `simple_poppy` |
| Wild Poppy | Wilder Mohn | cross | `wild_poppy` |
| Rose | Rose | cross | `rose` |
| Classic Rose | Klassische Rose | cross | `classic_rose` |
| Rose Cluster | Rosengruppe | crop | `rose_cluster` |
| Golden Rose | Goldene Rose | cross | `golden_rose` |
| Dark Golden Rose | Dunkle Goldrose | cross | `dark_golden_rose` |
| Low Rose | Niedrige Rose | cross | `low_rose` |
| White Rose | Weiße Rose | cross | `white_rose` |
| Shrub | Strauch | cross | `shrub` |
| Dark Shrub | Dunkler Strauch | cross | `dark_shrub` |
| Dead Shrub | Verdorrter Strauch | cross | `dead_shrub` |
| Green Shrub | Grüner Strauch | cross | `green_shrub` |
| Orange Shrub | Oranger Strauch | cross | `orange_shrub` |
| Blue Pine Shrub | Blauer Kiefernstrauch | cross | `blue_pine_shrub` |
| Green Pine Shrub | Grüner Kiefernstrauch | cross | `green_pine_shrub` |
| Red Shrub | Roter Strauch | cross | `red_shrub` |
| Woody Shrub | Holziger Strauch | cross | `woody_shrub` |
| Swamp Roots | Sumpfwurzeln | cross | `swamp_roots` |
| Lilac | Flieder | cross | `lilac` |
| Tulip | Tulpe | cross | `tulip` |
| Orange Tulip Group | Orange Tulpengruppe | crop | `orange_tulip_group` |
| Pink Tulip Group | Rosa Tulpengruppe | crop | `pink_tulip_group` |
| Purple Tulip Group | Lila Tulpengruppe | crop | `purple_tulip_group` |
| Red Tulip Group | Rote Tulpengruppe | crop | `red_tulip_group` |
| White Tulip Group | Weiße Tulpengruppe | crop | `white_tulip_group` |
| Yellow Tulip Group | Gelbe Tulpengruppe | crop | `yellow_tulip_group` |
| Simple Orange Tulip | Schlichte orange Tulpe | cross | `simple_orange_tulip` |
| Simple Pink Tulip | Schlichte rosa Tulpe | cross | `simple_pink_tulip` |
| Simple Purple Tulip | Schlichte lila Tulpe | cross | `simple_purple_tulip` |
| Simple Red Tulip | Schlichte rote Tulpe | cross | `simple_red_tulip` |
| Simple White Tulip | Schlichte weiße Tulpe | cross | `simple_white_tulip` |
| Simple Yellow Tulip | Schlichte gelbe Tulpe | cross | `simple_yellow_tulip` |
| Turnip Plant | Steckrübenkraut | cross | `turnip_plant` |
| Violet | Veilchen | cross | `violet` |
| Violet Field | Veilchenfeld | crop | `violet_field` |
| Low Violets | Niedrige Veilchen | cross | `low_violets` |
| White Anemone Field | Buschwindröschenfeld | crop | `white_anemone_field` |
| Low White Anemones | Niedrige Buschwindröschen | cross | `low_white_anemones` |
| Low Wildflowers | Niedrige Wildblumen | cross | `low_wildflowers` |
| Large Wildflowers | Große Wildblumen | cross | `large_wildflowers` |
| Simple Wildflowers | Schlichte Wildblumen | cross | `simple_wildflowers` |
| Small Wildflowers | Kleine Wildblumen | cross | `small_wildflowers` |
| Bush (Biome Dark) | Busch (Biom dunkel) | cross | `bush_biome_dark` |
| Curly Grass (Biome Dark) | Gekräuseltes Gras (Biom dunkel) | cross | `curly_grass_biome_dark` |
| Fern (Biome Dark) | Farn (Biom dunkel) | cross | `fern_biome_dark` |
| Grain Grass (Biome Dark) | Getreidegras (Biom dunkel) | crop | `grain_grass_biome_dark` |
| Large Grass (Biome Dark) | Großes Gras (Biom dunkel) | cross | `large_grass_biome_dark` |
| Medium Grass (Biome Dark) | Mittleres Gras (Biom dunkel) | cross | `medium_grass_biome_dark` |
| Small Grass (Biome Dark) | Kleines Gras (Biom dunkel) | cross | `small_grass_biome_dark` |
| Tiny Grass (Biome Dark) | Winziges Gras (Biom dunkel) | cross | `tiny_grass_biome_dark` |
| Hay Grass (Biome Dark) | Heugras (Biom dunkel) | crop | `hay_grass_biome_dark` |
| Lawn (Biome Dark) | Rasen (Biom dunkel) | crop | `lawn_biome_dark` |
| Long Lawn (Biome Dark) | Langer Rasen (Biom dunkel) | crop | `long_lawn_biome_dark` |
| Large Scrub (Biome Dark) | Großes Gestrüpp (Biom dunkel) | cross | `large_scrub_biome_dark` |
| Medium Scrub (Biome Dark) | Mittleres Gestrüpp (Biom dunkel) | cross | `medium_scrub_biome_dark` |
| Small Scrub (Biome Dark) | Kleines Gestrüpp (Biom dunkel) | cross | `small_scrub_biome_dark` |
| Simple Grass (Biome Dark) | Schlichtes Gras (Biom dunkel) | crop | `simple_grass_biome_dark` |
| Tall Simple Grass (Biome Dark) | Hohes schlichtes Gras (Biom dunkel) | crop | `tall_simple_grass_biome_dark` |
| Grass Sprout (Biome Dark) | Grassprössling (Biom dunkel) | cross | `grass_sprout_biome_dark` |
| Curly Grass (Biome Faded) | Gekräuseltes Gras (Biom verblasst) | cross | `curly_grass_biome_faded` |
| Fern (Biome Faded) | Farn (Biom verblasst) | cross | `fern_biome_faded` |
| Grain Grass (Biome Faded) | Getreidegras (Biom verblasst) | crop | `grain_grass_biome_faded` |
| Large Grass (Biome Faded) | Großes Gras (Biom verblasst) | cross | `large_grass_biome_faded` |
| Medium Grass (Biome Faded) | Mittleres Gras (Biom verblasst) | cross | `medium_grass_biome_faded` |
| Small Grass (Biome Faded) | Kleines Gras (Biom verblasst) | cross | `small_grass_biome_faded` |
| Tiny Grass (Biome Faded) | Winziges Gras (Biom verblasst) | cross | `tiny_grass_biome_faded` |
| Hay Grass (Biome Faded) | Heugras (Biom verblasst) | crop | `hay_grass_biome_faded` |
| Lawn (Biome Faded) | Rasen (Biom verblasst) | crop | `lawn_biome_faded` |
| Long Lawn (Biome Faded) | Langer Rasen (Biom verblasst) | crop | `long_lawn_biome_faded` |
| Large Scrub (Biome Faded) | Großes Gestrüpp (Biom verblasst) | cross | `large_scrub_biome_faded` |
| Medium Scrub (Biome Faded) | Mittleres Gestrüpp (Biom verblasst) | cross | `medium_scrub_biome_faded` |
| Small Scrub (Biome Faded) | Kleines Gestrüpp (Biom verblasst) | cross | `small_scrub_biome_faded` |
| Shrub (Biome Faded) | Strauch (Biom verblasst) | cross | `shrub_biome_faded` |
| Simple Grass (Biome Faded) | Schlichtes Gras (Biom verblasst) | crop | `simple_grass_biome_faded` |
| Tall Simple Grass (Biome Faded) | Hohes schlichtes Gras (Biom verblasst) | crop | `tall_simple_grass_biome_faded` |
| Grass Sprout (Biome Faded) | Grassprössling (Biom verblasst) | cross | `grass_sprout_biome_faded` |
| Curly Grass (Biome Light) | Gekräuseltes Gras (Biom hell) | cross | `curly_grass_biome_light` |
| Fern (Biome Light) | Farn (Biom hell) | cross | `fern_biome_light` |
| Grain Grass (Biome Light) | Getreidegras (Biom hell) | crop | `grain_grass_biome_light` |
| Large Grass (Biome Light) | Großes Gras (Biom hell) | cross | `large_grass_biome_light` |
| Medium Grass (Biome Light) | Mittleres Gras (Biom hell) | cross | `medium_grass_biome_light` |
| Small Grass (Biome Light) | Kleines Gras (Biom hell) | cross | `small_grass_biome_light` |
| Tiny Grass (Biome Light) | Winziges Gras (Biom hell) | cross | `tiny_grass_biome_light` |
| Hay Grass (Biome Light) | Heugras (Biom hell) | crop | `hay_grass_biome_light` |
| Lawn (Biome Light) | Rasen (Biom hell) | crop | `lawn_biome_light` |
| Long Lawn (Biome Light) | Langer Rasen (Biom hell) | crop | `long_lawn_biome_light` |
| Medium Scrub (Biome Light) | Mittleres Gestrüpp (Biom hell) | cross | `medium_scrub_biome_light` |
| Small Scrub (Biome Light) | Kleines Gestrüpp (Biom hell) | cross | `small_scrub_biome_light` |
| Tall Scrub (Biome Light) | Hohes Gestrüpp (Biom hell) | cross | `tall_scrub_biome_light` |
| Shrub (Biome Light) | Strauch (Biom hell) | cross | `shrub_biome_light` |
| Simple Grass (Biome Light) | Schlichtes Gras (Biom hell) | crop | `simple_grass_biome_light` |
| Tall Simple Grass (Biome Light) | Hohes schlichtes Gras (Biom hell) | crop | `tall_simple_grass_biome_light` |
| Grass Sprout (Biome Light) | Grassprössling (Biom hell) | cross | `grass_sprout_biome_light` |
| Dead Bush | Verdorrter Busch | cross | `dead_bush` |
| Curly Dead Grass | Gekräuseltes verdorrtes Gras | cross | `curly_dead_grass` |
| Dead Fern | Verdorrter Farn | cross | `dead_fern` |
| Dead Grain Grass | Verdorrtes Getreidegras | crop | `dead_grain_grass` |
| Large Dead Grass | Großes verdorrtes Gras | cross | `large_dead_grass` |
| Medium Dead Grass | Mittleres verdorrtes Gras | cross | `medium_dead_grass` |
| Small Dead Grass | Kleines verdorrtes Gras | cross | `small_dead_grass` |
| Tiny Dead Grass | Winziges verdorrtes Gras | cross | `tiny_dead_grass` |
| Dead Hay Grass | Verdorrtes Heugras | crop | `dead_hay_grass` |
| Dead Lawn | Verdorrter Rasen | crop | `dead_lawn` |
| Long Dead Lawn | Langer verdorrter Rasen | crop | `long_dead_lawn` |
| Medium Dead Scrub | Mittleres verdorrtes Gestrüpp | cross | `medium_dead_scrub` |
| Small Dead Scrub | Kleines verdorrtes Gestrüpp | cross | `small_dead_scrub` |
| Tall Dead Scrub | Hohes verdorrtes Gestrüpp | cross | `tall_dead_scrub` |
| Simple Dead Grass | Schlichtes verdorrtes Gras | crop | `simple_dead_grass` |
| Tall Simple Dead Grass | Hohes schlichtes verdorrtes Gras | crop | `tall_simple_dead_grass` |
| Dead Grass Sprout | Verdorrter Grassprössling | cross | `dead_grass_sprout` |
| Curly Green Grass | Gekräuseltes grünes Gras | cross | `curly_green_grass` |
| Dark Green Bush | Dunkelgrüner Busch | cross | `dark_green_bush` |
| Curly Dark Green Grass | Gekräuseltes dunkelgrünes Gras | cross | `curly_dark_green_grass` |
| Dark Green Fern | Dunkelgrüner Farn | cross | `dark_green_fern` |
| Dark Green Grain Grass | Dunkelgrünes Getreidegras | crop | `dark_green_grain_grass` |
| Large Dark Green Grass | Großes dunkelgrünes Gras | cross | `large_dark_green_grass` |
| Medium Dark Green Grass | Mittleres dunkelgrünes Gras | cross | `medium_dark_green_grass` |
| Small Dark Green Grass | Kleines dunkelgrünes Gras | cross | `small_dark_green_grass` |
| Tiny Dark Green Grass | Winziges dunkelgrünes Gras | cross | `tiny_dark_green_grass` |
| Dark Green Hay Grass | Dunkelgrünes Heugras | crop | `dark_green_hay_grass` |
| Dark Green Lawn | Dunkelgrüner Rasen | crop | `dark_green_lawn` |
| Long Dark Green Lawn | Langer dunkelgrüner Rasen | crop | `long_dark_green_lawn` |
| Large Dark Green Scrub | Großes dunkelgrünes Gestrüpp | cross | `large_dark_green_scrub` |
| Medium Dark Green Scrub | Mittleres dunkelgrünes Gestrüpp | cross | `medium_dark_green_scrub` |
| Small Dark Green Scrub | Kleines dunkelgrünes Gestrüpp | cross | `small_dark_green_scrub` |
| Simple Dark Green Grass | Schlichtes dunkelgrünes Gras | crop | `simple_dark_green_grass` |
| Tall Simple Dark Green Grass | Hohes schlichtes dunkelgrünes Gras | crop | `tall_simple_dark_green_grass` |
| Dark Green Grass Sprout | Dunkelgrüner Grassprössling | cross | `dark_green_grass_sprout` |
| Green Fern | Grüner Farn | cross | `green_fern` |
| Green Grain Grass | Grünes Getreidegras | crop | `green_grain_grass` |
| Large Green Grass | Großes grünes Gras | cross | `large_green_grass` |
| Medium Green Grass | Mittleres grünes Gras | cross | `medium_green_grass` |
| Small Green Grass | Kleines grünes Gras | cross | `small_green_grass` |
| Tiny Green Grass | Winziges grünes Gras | cross | `tiny_green_grass` |
| Green Hay Grass | Grünes Heugras | crop | `green_hay_grass` |
| Green Lawn | Grüner Rasen | crop | `green_lawn` |
| Long Green Lawn | Langer grüner Rasen | crop | `long_green_lawn` |
| Medium Green Scrub | Mittleres grünes Gestrüpp | cross | `medium_green_scrub` |
| Short Green Shrub | Niedriger grüner Strauch | cross | `short_green_shrub` |
| Tall Green Shrub | Hoher grüner Strauch | cross | `tall_green_shrub` |
| Simple Green Grass | Schlichtes grünes Gras | crop | `simple_green_grass` |
| Tall Simple Green Grass | Hohes schlichtes grünes Gras | crop | `tall_simple_green_grass` |
| Green Grass Sprout | Grüner Grassprössling | cross | `green_grass_sprout` |
| Red Bush | Roter Busch | cross | `red_bush` |
| Curly Red Grass | Gekräuseltes rotes Gras | cross | `curly_red_grass` |
| Red Fern | Roter Farn | cross | `red_fern` |
| Red Grain Grass | Rotes Getreidegras | crop | `red_grain_grass` |
| Large Red Grass | Großes rotes Gras | cross | `large_red_grass` |
| Medium Red Grass | Mittleres rotes Gras | cross | `medium_red_grass` |
| Small Red Grass | Kleines rotes Gras | cross | `small_red_grass` |
| Tiny Red Grass | Winziges rotes Gras | cross | `tiny_red_grass` |
| Red Hay Grass | Rotes Heugras | crop | `red_hay_grass` |
| Red Lawn | Roter Rasen | crop | `red_lawn` |
| Long Red Lawn | Langer roter Rasen | crop | `long_red_lawn` |
| Medium Red Scrub | Mittleres rotes Gestrüpp | cross | `medium_red_scrub` |
| Short Red Scrub | Niedriges rotes Gestrüpp | cross | `short_red_scrub` |
| Tall Red Scrub | Hohes rotes Gestrüpp | cross | `tall_red_scrub` |
| Simple Red Grass | Schlichtes rotes Gras | crop | `simple_red_grass` |
| Tall Simple Red Grass | Hohes schlichtes rotes Gras | crop | `tall_simple_red_grass` |
| Red Grass Sprout | Roter Grassprössling | cross | `red_grass_sprout` |
| Tall Grass (Biome Dark) | Hohes Gras (Biom dunkel) | tall | `tall_grass_biome_dark` |
| Tall Bush (Biome Dark) | Hoher Busch (Biom dunkel) | tall | `tall_bush_biome_dark` |
| Large Fern (Biome Dark) | Großer Farn (Biom dunkel) | tall | `large_fern_biome_dark` |
| Tall Hay Grass (Biome Dark) | Hohes Heugras (Biom dunkel) | tall | `tall_hay_grass_biome_dark` |
| Tall Lawn (Biome Dark) | Hoher Rasen (Biom dunkel) | tall | `tall_lawn_biome_dark` |
| Tall Grass (Biome Faded) | Hohes Gras (Biom verblasst) | tall | `tall_grass_biome_faded` |
| Tall Bush (Biome Faded) | Hoher Busch (Biom verblasst) | tall | `tall_bush_biome_faded` |
| Large Fern (Biome Faded) | Großer Farn (Biom verblasst) | tall | `large_fern_biome_faded` |
| Tall Hay Grass (Biome Faded) | Hohes Heugras (Biom verblasst) | tall | `tall_hay_grass_biome_faded` |
| Tall Lawn (Biome Faded) | Hoher Rasen (Biom verblasst) | tall | `tall_lawn_biome_faded` |
| Tall Grass (Biome Light) | Hohes Gras (Biom hell) | tall | `tall_grass_biome_light` |
| Tall Bush (Biome Light) | Hoher Busch (Biom hell) | tall | `tall_bush_biome_light` |
| Large Fern (Biome Light) | Großer Farn (Biom hell) | tall | `large_fern_biome_light` |
| Tall Hay Grass (Biome Light) | Hohes Heugras (Biom hell) | tall | `tall_hay_grass_biome_light` |
| Tall Lawn (Biome Light) | Hoher Rasen (Biom hell) | tall | `tall_lawn_biome_light` |
| Classic Large Fern | Klassischer Großer Farn | tall | `classic_large_fern` |
| Tall Dead Grass | Hohes verdorrtes Gras | tall | `tall_dead_grass` |
| Tall Dead Bush | Hoher verdorrter Busch | tall | `tall_dead_bush` |
| Large Dead Fern | Großer verdorrter Farn | tall | `large_dead_fern` |
| Tall Dead Hay Grass | Hohes verdorrtes Heugras | tall | `tall_dead_hay_grass` |
| Tall Dead Lawn | Hoher verdorrter Rasen | tall | `tall_dead_lawn` |
| Tall Green Grass | Hohes grünes Gras | tall | `tall_green_grass` |
| Tall Green Bush | Hoher grüner Busch | tall | `tall_green_bush` |
| Tall Dark Green Grass | Hohes dunkelgrünes Gras | tall | `tall_dark_green_grass` |
| Tall Dark Green Bush | Hoher dunkelgrüner Busch | tall | `tall_dark_green_bush` |
| Large Dark Green Fern | Großer dunkelgrüner Farn | tall | `large_dark_green_fern` |
| Tall Dark Green Hay Grass | Hohes dunkelgrünes Heugras | tall | `tall_dark_green_hay_grass` |
| Tall Dark Green Lawn | Hoher dunkelgrüner Rasen | tall | `tall_dark_green_lawn` |
| Large Green Fern | Großer grüner Farn | tall | `large_green_fern` |
| Tall Green Hay Grass | Hohes grünes Heugras | tall | `tall_green_hay_grass` |
| Tall Green Lawn | Hoher grüner Rasen | tall | `tall_green_lawn` |
| Tall Red Grass | Hohes rotes Gras | tall | `tall_red_grass` |
| Tall Red Bush | Hoher roter Busch | tall | `tall_red_bush` |
| Large Red Fern | Großer roter Farn | tall | `large_red_fern` |
| Tall Red Hay Grass | Hohes rotes Heugras | tall | `tall_red_hay_grass` |
| Tall Red Lawn | Hoher roter Rasen | tall | `tall_red_lawn` |
| Autumn Bush | Herbstbusch | tall | `autumn_bush` |
| Plain Bush | Schlichter Busch | tall | `plain_bush` |
| Tall Brown Cactus | Hoher brauner Kaktus | tall | `tall_brown_cactus` |
| Tall Green Cactus | Hoher grüner Kaktus | tall | `tall_green_cactus` |
| Tall Olive Cactus | Hoher olivgrüner Kaktus | tall | `tall_olive_cactus` |
| Tall Cattail | Hoher Rohrkolben | tall | `tall_cattail` |
| Cornstalks | Maisstängel | tall | `cornstalks` |
| Tall Flax | Hoher Flachs | tall | `tall_flax` |
| Tall Purple Flax | Hoher lila Flachs | tall | `tall_purple_flax` |
| Green Grapevine | Grüner Weinstock | tall | `green_grapevine` |
| Red Grapevine | Roter Weinstock | tall | `red_grapevine` |
| Giant Button Mushroom | Riesenchampignon | tall | `giant_button_mushroom` |
| Giant Death Cap | Riesenknollenblätterpilz | tall | `giant_death_cap` |
| Giant Toadstool | Riesengiftpilz | tall | `giant_toadstool` |
| Tall Peony | Hohe Pfingstrose | tall | `tall_peony` |
| Pineapple Plant | Ananaspflanze | tall | `pineapple_plant` |
| Classic Rose Bush | Klassischer Rosenstrauch | tall | `classic_rose_bush` |
| Golden Rose Bush | Goldener Rosenstrauch | tall | `golden_rose_bush` |
| Red Rose Bush | Roter Rosenstrauch | tall | `red_rose_bush` |
| Tall Blue Pine Shrub | Hoher blauer Kiefernstrauch | tall | `tall_blue_pine_shrub` |
| Tall Green Pine Shrub | Hoher grüner Kiefernstrauch | tall | `tall_green_pine_shrub` |
| Lilac Bush | Fliederbusch | tall | `lilac_bush` |
| Short Topiary | Niedriger Formschnitt | tall | `short_topiary` |
| Tall Topiary | Hoher Formschnitt | tall | `tall_topiary` |
| Slim Topiary | Schlanker Formschnitt | tall | `slim_topiary` |
| Tropical Flower | Tropenblume | tall | `tropical_flower` |
| Tropical Plant | Tropenpflanze | tall | `tropical_plant` |
| Golden Sunflower Stalks | Goldene Sonnenblumenstängel | tall | `golden_sunflower_stalks` |
| Mixed Sunflower Stalks | Gemischte Sonnenblumenstängel | tall | `mixed_sunflower_stalks` |
| Red Sunflower Stalks | Rote Sonnenblumenstängel | tall | `red_sunflower_stalks` |
| White Sunflower Stalks | Weiße Sonnenblumenstängel | tall | `white_sunflower_stalks` |
| Classic Sunflower Stalk | Klassischer Sonnenblumenstängel | tall | `classic_sunflower_stalk` |
| Round Golden Sunflower | Runde goldene Sonnenblume | sunflower | `round_golden_sunflower` |
| Round Red Sunflower | Runde rote Sonnenblume | sunflower | `round_red_sunflower` |
| Round White Sunflower | Runde weiße Sonnenblume | sunflower | `round_white_sunflower` |
| Mixed Sunflower Cluster | Gemischte Sonnenblumengruppe | sunflower | `mixed_sunflower_cluster` |
| Golden Sunflower Cluster | Goldene Sonnenblumengruppe | sunflower | `golden_sunflower_cluster` |
| Red Sunflower Cluster | Rote Sonnenblumengruppe | sunflower | `red_sunflower_cluster` |
| White Sunflower Cluster | Weiße Sonnenblumengruppe | sunflower | `white_sunflower_cluster` |
| Tall Poinsettia | Hoher Weihnachtsstern | sunflower | `tall_poinsettia` |
| Tall Dark Shrub | Hoher dunkler Strauch | tall | `tall_dark_shrub` |
| Tall Shrub with Red Flowers | Hoher Strauch mit roten Blüten | tall | `tall_shrub_with_red_flowers` |
| Tall Shrub with White Flowers | Hoher Strauch mit weißen Blüten | tall | `tall_shrub_with_white_flowers` |
| Tall Green Shrub (Offlawn) | Hoher grüner Strauch (Offlawn) | tall | `tall_green_shrub_offlawn` |
| Tall Red Shrub | Hoher roter Strauch | tall | `tall_red_shrub` |
| Tall Golden Sunflower | Hohe goldene Sonnenblume | tall | `tall_golden_sunflower` |
| Tall Red Sunflower | Hohe rote Sonnenblume | tall | `tall_red_sunflower` |
| Tall White Sunflower | Hohe weiße Sonnenblume | tall | `tall_white_sunflower` |
| Wild Tall Grass (Biome Dark) | Hohes Wildgras (Biom dunkel) | tall | `wild_tall_grass_biome_dark` |
| Wild Tall Grass (Biome Light) | Hohes Wildgras (Biom hell) | tall | `wild_tall_grass_biome_light` |
| Green Acacia Sapling | Grüner Akaziensetzling | cross | `green_acacia_sapling` |
| Yellow Acacia Sapling | Gelber Akaziensetzling | cross | `yellow_acacia_sapling` |
| Brown Autumn Sapling | Brauner Herbstsetzling | cross | `brown_autumn_sapling` |
| Dark Orange Autumn Sapling | Dunkelorange Herbstsetzling | cross | `dark_orange_autumn_sapling` |
| Orange Autumn Sapling | Oranger Herbstsetzling | cross | `orange_autumn_sapling` |
| Pink Autumn Sapling | Rosa Herbstsetzling | cross | `pink_autumn_sapling` |
| Red Autumn Sapling | Roter Herbstsetzling | cross | `red_autumn_sapling` |
| Yellow Autumn Sapling | Gelber Herbstsetzling | cross | `yellow_autumn_sapling` |
| Birch Sapling | Birkensetzling | cross | `birch_sapling` |
| Autumn Birch Sapling | Herbstbirkensetzling | cross | `autumn_birch_sapling` |
| Dark Birch Sapling | Dunkler Birkensetzling | cross | `dark_birch_sapling` |
| Dark Autumn Birch Sapling | Dunkler Herbstbirkensetzling | cross | `dark_autumn_birch_sapling` |
| Wild Dark Birch Sapling | Wilder dunkler Birkensetzling | cross | `wild_dark_birch_sapling` |
| Wild Birch Sapling | Wilder Birkensetzling | cross | `wild_birch_sapling` |
| Bonsai | Bonsai | cross | `bonsai` |
| Cedar Bonsai | Zedernbonsai | cross | `cedar_bonsai` |
| Fir Sapling | Tannensetzling | cross | `fir_sapling` |
| Jungle Sapling | Tropenbaum-Setzling | cross | `jungle_sapling` |
| Cocoa Jungle Sapling | Kakao-Tropenbaum-Setzling | cross | `cocoa_jungle_sapling` |
| Yellow Jungle Sapling | Gelber Tropenbaum-Setzling | cross | `yellow_jungle_sapling` |
| Leafy Shrub Sapling | Blättriger Strauchsetzling | cross | `leafy_shrub_sapling` |
| Autumn Oak Sapling | Herbsteichensetzling | cross | `autumn_oak_sapling` |
| Dead Oak Sapling | Toter Eichensetzling | cross | `dead_oak_sapling` |
| Green Oak Sapling | Grüner Eichensetzling | cross | `green_oak_sapling` |
| Dark Green Oak Sapling | Dunkelgrüner Eichensetzling | cross | `dark_green_oak_sapling` |
| Olive Oak Sapling | Olivgrüner Eichensetzling | cross | `olive_oak_sapling` |
| Robust Oak Sapling | Kräftiger Eichensetzling | cross | `robust_oak_sapling` |
| Wild Oak Sapling | Wilder Eichensetzling | cross | `wild_oak_sapling` |
| Palm Sapling | Palmensetzling | cross | `palm_sapling` |
| Pine Sapling | Kiefernsetzling | cross | `pine_sapling` |
| Branching Pine Sapling | Verzweigter Kiefernsetzling | cross | `branching_pine_sapling` |
| Dark Pine Sapling | Dunkler Kiefernsetzling | cross | `dark_pine_sapling` |
| Spruce Pine Sapling | Fichtenkiefern-Setzling | cross | `spruce_pine_sapling` |
| Redwood Sapling | Mammutbaumsetzling | cross | `redwood_sapling` |
| Upper Redwood Sapling | Mammutbaumkronen-Setzling | cross | `upper_redwood_sapling` |
| Robust Brown Autumn Sapling | Kräftiger brauner Herbstsetzling | cross | `robust_brown_autumn_sapling` |
| Robust Dark Orange Autumn Sapling | Kräftiger dunkelorange Herbstsetzling | cross | `robust_dark_orange_autumn_sapling` |
| Robust Orange Autumn Sapling | Kräftiger oranger Herbstsetzling | cross | `robust_orange_autumn_sapling` |
| Robust Pink Autumn Sapling | Kräftiger rosa Herbstsetzling | cross | `robust_pink_autumn_sapling` |
| Robust Red Autumn Sapling | Kräftiger roter Herbstsetzling | cross | `robust_red_autumn_sapling` |
| Robust Yellow Autumn Sapling | Kräftiger gelber Herbstsetzling | cross | `robust_yellow_autumn_sapling` |
| Robust Dead Sapling | Kräftiger toter Setzling | cross | `robust_dead_sapling` |
| Robust Orange Sapling | Kräftiger oranger Setzling | cross | `robust_orange_sapling` |
| Robust Sapling with Pink Petals | Kräftiger Setzling mit rosa Blüten | cross | `robust_sapling_with_pink_petals` |
| Robust Red Sapling | Kräftiger roter Setzling | cross | `robust_red_sapling` |
| Robust Silver Sapling | Kräftiger silberner Setzling | cross | `robust_silver_sapling` |
| Robust Marsh Silver Sapling | Kräftiger Sumpfsilber-Setzling | cross | `robust_marsh_silver_sapling` |
| Robust Sapling with White Petals | Kräftiger Setzling mit weißen Blüten | cross | `robust_sapling_with_white_petals` |
| Robust Yellow Sapling | Kräftiger gelber Setzling | cross | `robust_yellow_sapling` |
| Ivy (Biome Dark) | Efeu (Biom dunkel) | vine | `ivy_biome_dark` |
| Leafy Vine (Biome Dark) | Blättrige Ranke (Biom dunkel) | vine | `leafy_vine_biome_dark` |
| Thick Vine (Biome Dark) | Dicke Ranke (Biom dunkel) | vine | `thick_vine_biome_dark` |
| Thin Vine (Biome Dark) | Dünne Ranke (Biom dunkel) | vine | `thin_vine_biome_dark` |
| Ivy (Biome Light) | Efeu (Biom hell) | vine | `ivy_biome_light` |
| Flowering Ivy (Biome Light) | Blühender Efeu (Biom hell) | vine | `flowering_ivy_biome_light` |
| Vine Ladder (Biome Light) | Rankenleiter (Biom hell) | vine | `vine_ladder_biome_light` |
| Leafy Vine (Biome Light) | Blättrige Ranke (Biom hell) | vine | `leafy_vine_biome_light` |
| Thick Vine (Biome Light) | Dicke Ranke (Biom hell) | vine | `thick_vine_biome_light` |
| Thin Vine (Biome Light) | Dünne Ranke (Biom hell) | vine | `thin_vine_biome_light` |
| Vine Ladder (Biome Dark) | Rankenleiter (Biom dunkel) | vine | `vine_ladder_biome_dark` |
| Dead Vine Ladder | Verdorrte Rankenleiter | vine | `dead_vine_ladder` |
| Dead Leafy Vine | Blättrige verdorrte Ranke | vine | `dead_leafy_vine` |
| Dead Thick Vine | Dicke verdorrte Ranke | vine | `dead_thick_vine` |
| Dead Thin Vine | Dünne verdorrte Ranke | vine | `dead_thin_vine` |
| Ivy with Red Flowers | Efeu mit roten Blüten | vine | `ivy_with_red_flowers` |
| Ivy with White Flowers | Efeu mit weißen Blüten | vine | `ivy_with_white_flowers` |
| Green Vine Ladder | Grüne Rankenleiter | vine | `green_vine_ladder` |
| Green Leafy Vine | Blättrige grüne Ranke | vine | `green_leafy_vine` |
| Green Thick Vine | Dicke grüne Ranke | vine | `green_thick_vine` |
| Green Thin Vine | Dünne grüne Ranke | vine | `green_thin_vine` |
| Thick Mystic Vine | Dicke mystische Ranke | vine | `thick_mystic_vine` |
| Wild Grass Vine | Wildgras-Ranke | vine | `wild_grass_vine` |
| Lily Pad (Biome Dark) | Seerosenblatt (Biom dunkel) | lily | `lily_pad_biome_dark` |
| Lily Pad Top View (Biome Dark) | Seerosenblatt, Draufsicht (Biom dunkel) | lily | `lily_pad_top_view_biome_dark` |
| Lily Pad (Biome Light) | Seerosenblatt (Biom hell) | lily | `lily_pad_biome_light` |
| Lily Pad Top View (Biome Light) | Seerosenblatt, Draufsicht (Biom hell) | lily | `lily_pad_top_view_biome_light` |
| Green Lily Pad | Grünes Seerosenblatt | lily | `green_lily_pad` |
| Flowering Green Lily Pad | Blühendes grünes Seerosenblatt | lily | `flowering_green_lily_pad` |
| Green Lily Pad, Top View | Grünes Seerosenblatt, Draufsicht | lily | `green_lily_pad_top_view` |
| Flowering Green Lily Pad, Top View | Blühendes grünes Seerosenblatt, Draufsicht | lily | `flowering_green_lily_pad_top_view` |
| Pink Water Lily Blossom | Rosa Seerosenblüte | lily | `pink_water_lily_blossom` |
| White Water Lily Blossom | Weiße Seerosenblüte | lily | `white_water_lily_blossom` |
| Bamboo Cane | Bambusrohr | cross | `bamboo_cane` |
| Corn Stalk | Maishalm | cross | `corn_stalk` |
| Green Grape Cane | Grüne Weinrebe | cross | `green_grape_cane` |
| Red Grape Cane | Rote Weinrebe | cross | `red_grape_cane` |
| Vine Cane | Rankrohr | cross | `vine_cane` |
| Small Brown Cactus | Kleiner brauner Kaktus | cross | `small_brown_cactus` |
| Round Brown Cactus | Runder brauner Kaktus | cross | `round_brown_cactus` |
| Split Brown Cactus | Gespaltener brauner Kaktus | cross | `split_brown_cactus` |
| Small Green Cactus | Kleiner grüner Kaktus | cross | `small_green_cactus` |
| Round Green Cactus | Runder grüner Kaktus | cross | `round_green_cactus` |
| Split Green Cactus | Gespaltener grüner Kaktus | cross | `split_green_cactus` |
| Landworm Plant | Landwurmpflanze | cross | `landworm_plant` |
| Desert Lotus | Wüstenlotus | cross | `desert_lotus` |
| Small Olive Cactus | Kleiner olivgrüner Kaktus | cross | `small_olive_cactus` |
| Split Olive Cactus | Gespaltener olivgrüner Kaktus | cross | `split_olive_cactus` |
| Desert Scrub Grass | Wüstengestrüpp | cross | `desert_scrub_grass` |
| Autumn Mushroom | Herbstpilz | cross | `autumn_mushroom` |
| Tall Autumn Mushroom | Hoher Herbstpilz | cross | `tall_autumn_mushroom` |
| Button Mushroom | Champignon | cross | `button_mushroom` |
| Button Mushroom Cluster | Champignongruppe | cross | `button_mushroom_cluster` |
| Tall Button Mushroom | Hoher Champignon | cross | `tall_button_mushroom` |
| Button Toadstool | Champignon-Giftpilz | cross | `button_toadstool` |
| Death Cap | Knollenblätterpilz | cross | `death_cap` |
| Death Cap Cluster | Knollenblätterpilzgruppe | cross | `death_cap_cluster` |
| Tall Death Cap | Hoher Knollenblätterpilz | cross | `tall_death_cap` |
| Golden Mushroom | Goldener Pilz | cross | `golden_mushroom` |
| Golden Toadstool | Goldener Giftpilz | cross | `golden_toadstool` |
| Mixed Button Mushrooms | Gemischte Champignons | cross | `mixed_button_mushrooms` |
| Tall Mixed Button Mushrooms | Hohe gemischte Champignons | cross | `tall_mixed_button_mushrooms` |
| Mixed Toadstools | Gemischte Giftpilze | cross | `mixed_toadstools` |
| Tall Mixed Toadstools | Hohe gemischte Giftpilze | cross | `tall_mixed_toadstools` |
| Poison Mushroom | Gift-Totenkopfpilz | cross | `poison_mushroom` |
| Red Mushroom | Roter Pilz | cross | `red_mushroom` |
| Slime Mushroom | Schleimpilz | cross | `slime_mushroom` |
| Small Toadstool | Kleiner Giftpilz | cross | `small_toadstool` |
| Tall Toadstool | Hoher Giftpilz | cross | `tall_toadstool` |
| Brown Cactus | Brauner Kaktus | cactus | `brown_cactus` |
| Flowering Brown Cactus | Blühender brauner Kaktus | cactus | `flowering_brown_cactus` |
| Classic Cactus | Klassischer Kaktus | cactus | `classic_cactus` |
| Green Cactus | Grüner Kaktus | cactus | `green_cactus` |
| Flowering Green Cactus | Blühender grüner Kaktus | cactus | `flowering_green_cactus` |
| Landworm Cactus | Landwurm-Kaktus | cactus | `landworm_cactus` |
| Olive Cactus | Oliv Kaktus | cactus | `olive_cactus` |
| Snowman Cactus | Schneemann-Kaktus | cactus | `snowman_cactus` |
| White Blossom Foliage | Weißes Blütenlaub | cube | `white_blossom_foliage` |
| Full White Blossom Foliage | Volles weißes Blütenlaub | cube | `full_white_blossom_foliage` |
| Brown Autumn Shrub | Brauner Herbststrauch | cross | `brown_autumn_shrub` |
| Green Autumn Shrub | Grüner Herbststrauch | cross | `green_autumn_shrub` |
| Olive Autumn Shrub | Oliv Herbststrauch | cross | `olive_autumn_shrub` |
| Orange Autumn Shrub | Orange Herbststrauch | cross | `orange_autumn_shrub` |
| Red Autumn Shrub | Roter Herbststrauch | cross | `red_autumn_shrub` |
| Yellow Autumn Shrub | Gelber Herbststrauch | cross | `yellow_autumn_shrub` |
| Dense Cattails | Dichter Rohrkolben | cross | `dense_cattails` |
| Sparse Cattails | Lichter Rohrkolben | cross | `sparse_cattails` |
| Single Cattail | Einzelner Rohrkolben | cross | `single_cattail` |
| Ginger Group | Ingwerlilien-Gruppe | cross | `ginger_group` |
| Large Faded Grass (Ridge) | Großes verblasstes Gras (Hügelland) | cross | `large_faded_grass_ridge` |
| Medium Faded Grass (Ridge) | Mittleres verblasstes Gras (Hügelland) | cross | `medium_faded_grass_ridge` |
| Small Faded Grass (Ridge) | Kleines verblasstes Gras (Hügelland) | cross | `small_faded_grass_ridge` |
| Faded Hay (Ridge) | Verblasstes Heu (Hügelland) | crop | `faded_hay_ridge` |
| Large Faded Scrub (Ridge) | Großes verblasstes Gestrüpp (Hügelland) | cross | `large_faded_scrub_ridge` |
| Medium Faded Scrub (Ridge) | Mittleres verblasstes Gestrüpp (Hügelland) | cross | `medium_faded_scrub_ridge` |
| Small Faded Scrub (Ridge) | Kleines verblasstes Gestrüpp (Hügelland) | cross | `small_faded_scrub_ridge` |
| Large Red Grass (Ridge) | Großes rotes Gras (Hügelland) | cross | `large_red_grass_ridge` |
| Medium Red Grass (Ridge) | Mittleres rotes Gras (Hügelland) | cross | `medium_red_grass_ridge` |
| Small Red Grass (Ridge) | Kleines rotes Gras (Hügelland) | cross | `small_red_grass_ridge` |
| Red Hay (Ridge) | Rotes Heu (Hügelland) | crop | `red_hay_ridge` |
| Large Red Scrub (Ridge) | Großes rotes Gestrüpp (Hügelland) | cross | `large_red_scrub_ridge` |
| Medium Red Scrub (Ridge) | Mittleres rotes Gestrüpp (Hügelland) | cross | `medium_red_scrub_ridge` |
| Small Red Scrub (Ridge) | Kleines rotes Gestrüpp (Hügelland) | cross | `small_red_scrub_ridge` |
| Red Stone Shrub | Rotsteinstrauch | cross | `red_stone_shrub` |
| Dead Bellflower | Verdorrte Glockenblume | cross | `dead_bellflower` |
| Dead Cattail | Verdorrter Rohrkolben | cross | `dead_cattail` |
| Dead Grain | Verdorrtes Getreide | cross | `dead_grain` |
| Dead Nasturtium | Verdorrte Kapuzinerkresse | cross | `dead_nasturtium` |
| Dead Rose | Verdorrte Rose | cross | `dead_rose` |
| Large Grey Grass (Wasteland) | Großes graues Gras (Ödland) | cross | `large_grey_grass_wasteland` |
| Medium Grey Grass (Wasteland) | Mittleres graues Gras (Ödland) | cross | `medium_grey_grass_wasteland` |
| Small Grey Grass (Wasteland) | Kleines graues Gras (Ödland) | cross | `small_grey_grass_wasteland` |
| Grey Hay (Wasteland) | Graues Heu (Ödland) | crop | `grey_hay_wasteland` |
| Large Grey Scrub (Wasteland) | Großes graues Gestrüpp (Ödland) | cross | `large_grey_scrub_wasteland` |
| Medium Grey Scrub (Wasteland) | Mittleres graues Gestrüpp (Ödland) | cross | `medium_grey_scrub_wasteland` |
| Small Grey Scrub (Wasteland) | Kleines graues Gestrüpp (Ödland) | cross | `small_grey_scrub_wasteland` |
| Wasteland Landworm Plant | Ödland-Landwurmpflanze | cross | `wasteland_landworm_plant` |
| Brown Wasteland Shrub | Brauner Ödlandstrauch | cross | `brown_wasteland_shrub` |
| Grey Wasteland Shrub | Grauer Ödlandstrauch | cross | `grey_wasteland_shrub` |
| Yellow Wasteland Shrub | Gelber Ödlandstrauch | cross | `yellow_wasteland_shrub` |
| Large Yellow Grass (Wasteland) | Großes gelbes Gras (Ödland) | cross | `large_yellow_grass_wasteland` |
| Medium Yellow Grass (Wasteland) | Mittleres gelbes Gras (Ödland) | cross | `medium_yellow_grass_wasteland` |
| Small Yellow Grass (Wasteland) | Kleines gelbes Gras (Ödland) | cross | `small_yellow_grass_wasteland` |
| Yellow Hay (Wasteland) | Gelbes Heu (Ödland) | crop | `yellow_hay_wasteland` |
| Large Yellow Scrub (Wasteland) | Großes gelbes Gestrüpp (Ödland) | cross | `large_yellow_scrub_wasteland` |
| Medium Yellow Scrub (Wasteland) | Mittleres gelbes Gestrüpp (Ödland) | cross | `medium_yellow_scrub_wasteland` |
| Small Yellow Scrub (Wasteland) | Kleines gelbes Gestrüpp (Ödland) | cross | `small_yellow_scrub_wasteland` |
| Leaf Pile with Red Flower Cluster | Laubhaufen mit roter Blütengruppe | flat | `leaf_pile_with_red_flower_cluster` |
| Leaf Pile with Yellow Flower Cluster | Laubhaufen mit gelber Blütengruppe | flat | `leaf_pile_with_yellow_flower_cluster` |
| Leaf Pile with Blue Flowers | Laubhaufen mit blauen Blüten | flat | `leaf_pile_with_blue_flowers` |
| Leaf Pile with Red Flowers | Laubhaufen mit roten Blüten | flat | `leaf_pile_with_red_flowers` |
| Leaf Pile with White Flowers | Laubhaufen mit weißen Blüten | flat | `leaf_pile_with_white_flowers` |
| Leaf Pile with Wildflowers | Laubhaufen mit Wildblumen | flat | `leaf_pile_with_wildflowers` |
| Leaf Pile with Yellow Flowers | Laubhaufen mit gelben Blüten | flat | `leaf_pile_with_yellow_flowers` |
| Leaf Pile (Biome Dark) | Laubhaufen (Biom dunkel) | flat | `leaf_pile_biome_dark` |
| Leaf Pile (Biome Light) | Laubhaufen (Biom hell) | flat | `leaf_pile_biome_light` |
| Brown Leaf Pile | Brauner Laubhaufen | flat | `brown_leaf_pile` |
| Green Leaf Pile | Grüner Laubhaufen | flat | `green_leaf_pile` |
| Orange Leaf Pile | Oranger Laubhaufen | flat | `orange_leaf_pile` |
| Red Leaf Pile | Roter Laubhaufen | flat | `red_leaf_pile` |
| Yellow Leaf Pile | Gelber Laubhaufen | flat | `yellow_leaf_pile` |
| Bare Roots | Kahle Wurzeln | cross | `bare_roots` |
| Green Roots | Grüne Wurzeln | cross | `green_roots` |
| Classic Green Roots | Klassische grüne Wurzeln | cross | `classic_green_roots` |
| Green Roots with White Flowers | Grüne Wurzeln mit weißen Blüten | cross | `green_roots_with_white_flowers` |
| Olive Roots | Olivgrüne Wurzeln | cross | `olive_roots` |
| Classic Olive Roots | Klassische olivgrüne Wurzeln | cross | `classic_olive_roots` |
| Beanstalk Leaves with Red Flowers | Bohnenranken-Blätter mit roten Blüten | cross | `beanstalk_leaves_with_red_flowers` |
| Beanstalk Leaves with White Flowers | Bohnenranken-Blätter mit weißen Blüten | cross | `beanstalk_leaves_with_white_flowers` |
| Mixed Beanstalk Leaves with Red Flowers | Gemischte Bohnenranken-Blätter mit roten Blüten | cross | `mixed_beanstalk_leaves_with_red_flowers` |
| Mixed Beanstalk Leaves with White Flowers | Gemischte Bohnenranken-Blätter mit weißen Blüten | cross | `mixed_beanstalk_leaves_with_white_flowers` |
| Beanstalk Red Sunflower | Bohnenranke mit roter Sonnenblume | cross | `beanstalk_red_sunflower` |
| Beanstalk White Sunflower | Bohnenranke mit weißer Sonnenblume | cross | `beanstalk_white_sunflower` |
| Dead Beanstalk | Verdorrte Bohnenranke | cross | `dead_beanstalk` |
| Beanstalk with Red Flowers | Bohnenranke mit roten Blüten | cross | `beanstalk_with_red_flowers` |
| Beanstalk with White Flowers | Bohnenranke mit weißen Blüten | cross | `beanstalk_with_white_flowers` |
| Green Beanstalk | Grüne Bohnenranke | cross | `green_beanstalk` |
| Green Beanstalk with Orb | Grüne Bohnenranke mit Kugel | cross | `green_beanstalk_with_orb` |
| Green Beanstalk with Golden Sunflower | Grüne Bohnenranke mit goldener Sonnenblume | cross | `green_beanstalk_with_golden_sunflower` |
| Green Beanstalk with Red Sunflower | Grüne Bohnenranke mit roter Sonnenblume | cross | `green_beanstalk_with_red_sunflower` |
| Green Beanstalk with White Sunflower | Grüne Bohnenranke mit weißer Sonnenblume | cross | `green_beanstalk_with_white_sunflower` |
| Woody Beanstalk | Verholzte Bohnenranke | cross | `woody_beanstalk` |
| Woody Beanstalk with Orb | Verholzte Bohnenranke mit Kugel | cross | `woody_beanstalk_with_orb` |
| Woody Beanstalk with Golden Sunflower | Verholzte Bohnenranke mit goldener Sonnenblume | cross | `woody_beanstalk_with_golden_sunflower` |
| Woody Beanstalk with Red Sunflower | Verholzte Bohnenranke mit roter Sonnenblume | cross | `woody_beanstalk_with_red_sunflower` |
| Woody Beanstalk with White Sunflower | Verholzte Bohnenranke mit weißer Sonnenblume | cross | `woody_beanstalk_with_white_sunflower` |
| Cotton (Seedling) | Baumwolle (Keimling) | cross | `cotton_seedling` |
| Cotton (Growing) | Baumwolle (wachsend) | cross | `cotton_growing` |
| Cotton (Mature) | Baumwolle (ausgewachsen) | cross | `cotton_mature` |
| Fantasy Flower (Seedling) | Fantasieblume (Keimling) | cross | `fantasy_flower_seedling` |
| Fantasy Flower (Growing) | Fantasieblume (wachsend) | cross | `fantasy_flower_growing` |
| Flax (Seedling) | Flachs (Keimling) | cross | `flax_seedling` |
| Flax (Growing) | Flachs (wachsend) | cross | `flax_growing` |
| Flax (Mature) | Flachs (ausgewachsen) | cross | `flax_mature` |
| Olive Flax (Seedling) | Olivgrüner Flachs (Keimling) | cross | `olive_flax_seedling` |
| Olive Flax (Growing) | Olivgrüner Flachs (wachsend) | cross | `olive_flax_growing` |
| Olive Flax (Mature) | Olivgrüner Flachs (ausgewachsen) | cross | `olive_flax_mature` |
| Rope Grass (Seedling) | Seilgras (Keimling) | cross | `rope_grass_seedling` |
| Rope Grass (Growing) | Seilgras (wachsend) | cross | `rope_grass_growing` |
| Rope Grass (Mature) | Seilgras (ausgewachsen) | cross | `rope_grass_mature` |
| Autumn Fire Flower | Herbstliche Feuerblume | cross | `autumn_fire_flower` |
| Autumn Grass | Herbstgras | cross | `autumn_grass` |
| Autumn Hay | Herbstheu | cross | `autumn_hay` |
| Autumn Pumpkin Vine | Herbstliche Kürbisranke | cross | `autumn_pumpkin_vine` |
| Autumn Star Flower | Herbstliche Sternblume | cross | `autumn_star_flower` |
| Seasonal Corn Stalk | Saisonaler Maishalm | cross | `seasonal_corn_stalk` |
| Wilting Peony | Welkende Pfingstrose | cross | `wilting_peony` |
| Wilting Red Flower | Welkende rote Blume | cross | `wilting_red_flower` |
| Wilting Yellow Flower | Welkende gelbe Blume | cross | `wilting_yellow_flower` |
| Blue Flower Scatter | Blaue Blütenstreu | flat | `blue_flower_scatter` |
| Red Flower Scatter | Rote Blütenstreu | flat | `red_flower_scatter` |
| Wildflower Scatter | Wildblumenstreu | flat | `wildflower_scatter` |
| Yellow Flower Scatter | Gelbe Blütenstreu | flat | `yellow_flower_scatter` |
| Mystic Vine Strand | Mystischer Rankenstrang | cross | `mystic_vine_strand` |
| Mystic Vine Strand with Red Flowers | Mystischer Rankenstrang mit roten Blüten | cross | `mystic_vine_strand_with_red_flowers` |
| Mystic Vine Strand with White Flowers | Mystischer Rankenstrang mit weißen Blüten | cross | `mystic_vine_strand_with_white_flowers` |
