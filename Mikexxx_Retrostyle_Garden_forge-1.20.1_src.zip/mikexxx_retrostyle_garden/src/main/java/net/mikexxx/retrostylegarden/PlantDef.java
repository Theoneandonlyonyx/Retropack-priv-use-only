package net.mikexxx.retrostylegarden;

/** One decorative plant block, read from mikexxx_plants.txt. */
public record PlantDef(String id, String kind, char tint) {
}
