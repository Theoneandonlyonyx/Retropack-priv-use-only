package net.mikexxx.retrostylegarden;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PlaceOnWaterBlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CakeBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

/** Builds the right block / item for each shape type from the plant table. */
public final class PlantFactory {
    private PlantFactory() {
    }

    private static BlockBehaviour.Properties plant(boolean offset) {
        BlockBehaviour.Properties p = BlockBehaviour.Properties.of()
                .mapColor(MapColor.PLANT)
                .noCollission()
                .instabreak()
                .sound(SoundType.GRASS)
                .pushReaction(PushReaction.DESTROY);
        if (offset) {
            p = p.offsetType(BlockBehaviour.OffsetType.XZ);
        }
        return p;
    }

    /** Called for every kind except "bloom" (blossoms are items, not blocks). */
    public static Block createBlock(PlantDef def) {
        switch (def.kind()) {
            case "cross":
                return new RetroPlantBlock(plant(true), Block.box(2.0D, 0.0D, 2.0D, 14.0D, 13.0D, 14.0D), def.stack(), def.mushroom());
            case "crop":
                return new RetroPlantBlock(plant(true), Block.box(1.0D, 0.0D, 1.0D, 15.0D, 14.0D, 15.0D), def.stack(), false);
            case "flat":
                return new RetroPlantBlock(plant(false), Block.box(0.0D, 0.0D, 0.0D, 16.0D, 1.0D, 16.0D), false, false);
            case "tall":
            case "sunflower":
                return new RetroTallBlock(plant(true), def.stack(), def.mushroom());
            case "lily":
                return new RetroLilyPadBlock(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.PLANT)
                        .instabreak()
                        .sound(SoundType.LILY_PAD)
                        .noOcclusion()
                        .pushReaction(PushReaction.DESTROY));
            case "vine":
                return new VineBlock(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.PLANT)
                        .noCollission()
                        .strength(0.2F)
                        .sound(SoundType.VINE)
                        .pushReaction(PushReaction.DESTROY));
            case "cactus":
                return new RetroCactusBlock(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.PLANT)
                        .strength(0.4F)
                        .sound(SoundType.WOOL)
                        .noOcclusion());
            case "cube":
                return new Block(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.PLANT)
                        .strength(0.2F)
                        .sound(SoundType.GRASS)
                        .noOcclusion()
                        .isSuffocating((state, level, pos) -> false)
                        .isViewBlocking((state, level, pos) -> false));
            case "block":
                return new Block(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.STONE)
                        .strength(3.0F, 6.0F)
                        .requiresCorrectToolForDrops()
                        .sound(SoundType.METAL));
            case "cake":
                return new CakeBlock(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.WOOL)
                        .forceSolidOn()
                        .strength(0.5F)
                        .sound(SoundType.WOOL)
                        .pushReaction(PushReaction.DESTROY));
            default:
                throw new IllegalArgumentException("Unknown plant kind '" + def.kind() + "' for " + def.id());
        }
    }

    public static Item createItem(PlantDef def, Block block) {
        Item.Properties props = new Item.Properties();
        switch (def.kind()) {
            case "lily":
                return new PlaceOnWaterBlockItem(block, props);
            case "cake":
                return new BlockItem(block, props.stacksTo(1));
            case "tall":
            case "sunflower":
                return new net.minecraft.world.item.DoubleHighBlockItem(block, props);
            default:
                return new BlockItem(block, props);
        }
    }

    /** Blossoms have no block of their own: they are placed onto this mod's lily pads. */
    public static Item createBloomItem(PlantDef def) {
        return new LilyBloomItem(new Item.Properties(), Bloom.fromItemId(def.id()));
    }
}
