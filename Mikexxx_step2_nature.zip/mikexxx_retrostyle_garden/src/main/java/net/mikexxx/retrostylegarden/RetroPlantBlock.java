package net.mikexxx.retrostylegarden;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Small decorative plant: flowers, grass, ferns, shrubs, mushrooms, ground cover ... */
public class RetroPlantBlock extends BushBlock implements Stackable {
    private final VoxelShape shape;
    private final boolean stackable;
    private final boolean mushroom;

    public RetroPlantBlock(Properties properties, VoxelShape shape, boolean stackable, boolean mushroom) {
        super(properties);
        this.shape = shape;
        this.stackable = stackable;
        this.mushroom = mushroom;
    }

    /** Mushrooms behave like the vanilla ones: mycelium / podzol always, otherwise only in the dark on solid ground. */
    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        if (!mushroom) {
            return super.canSurvive(state, level, pos);
        }
        BlockPos below = pos.below();
        BlockState ground = level.getBlockState(below);
        if (ground.is(BlockTags.MUSHROOM_GROW_BLOCK)) {
            return true;
        }
        return level.getRawBrightness(pos, 0) < 13 && ground.isSolidRender(level, below);
    }

    @Override
    public boolean isStackable() {
        return stackable;
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (stackable && state.getBlock() instanceof Stackable other && other.isStackable()) {
            return true;
        }
        return state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(BlockTags.TERRACOTTA)
                || state.is(Blocks.FARMLAND) || state.is(Blocks.GRAVEL)
                || state.is(BlockTags.BASE_STONE_NETHER) || state.is(BlockTags.NYLIUM)
                || state.is(BlockTags.SOUL_SPEED_BLOCKS);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        Vec3 offset = state.getOffset(level, pos);
        return shape.move(offset.x, offset.y, offset.z);
    }
}
