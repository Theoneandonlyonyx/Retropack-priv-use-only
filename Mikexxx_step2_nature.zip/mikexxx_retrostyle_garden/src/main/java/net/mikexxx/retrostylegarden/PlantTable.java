package net.mikexxx.retrostylegarden;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Reads the block table that was generated together with the textures. */
public final class PlantTable {
    private PlantTable() {
    }

    public static List<PlantDef> load() {
        List<PlantDef> out = new ArrayList<>();
        try (InputStream in = PlantTable.class.getResourceAsStream("/mikexxx_plants.txt")) {
            if (in == null) {
                throw new IllegalStateException("mikexxx_plants.txt is missing from the mod jar");
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                String[] p = line.split("\\s+");
                boolean stack = Arrays.asList(p).subList(3, p.length).contains("stack");
                boolean mushroom = Arrays.asList(p).subList(3, p.length).contains("mushroom");
                out.add(new PlantDef(p[0], p[1], p[2].charAt(0), stack, mushroom));
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return out;
    }
}
