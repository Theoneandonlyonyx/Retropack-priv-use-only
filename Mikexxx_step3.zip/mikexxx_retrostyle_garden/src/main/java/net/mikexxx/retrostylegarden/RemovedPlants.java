package net.mikexxx.retrostylegarden;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.MissingMappingsEvent;

/**
 * Blocks / items that were removed from the mod (see removed_plants.txt). When an older world still contains them,
 * they are ignored silently: placed blocks turn into air and stacks disappear from inventories - no warning screen.
 */
public final class RemovedPlants {
    private static final Set<String> IDS = load();

    private RemovedPlants() {
    }

    private static Set<String> load() {
        Set<String> out = new HashSet<>();
        try (InputStream in = RemovedPlants.class.getResourceAsStream("/removed_plants.txt")) {
            if (in == null) {
                return out;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    out.add(line);
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return out;
    }

    public static void onMissingMappings(MissingMappingsEvent event) {
        for (MissingMappingsEvent.Mapping<Block> mapping : event.getMappings(ForgeRegistries.Keys.BLOCKS, RetrostyleGarden.MODID)) {
            if (IDS.contains(mapping.getKey().getPath())) {
                mapping.ignore();
            }
        }
        for (MissingMappingsEvent.Mapping<Item> mapping : event.getMappings(ForgeRegistries.Keys.ITEMS, RetrostyleGarden.MODID)) {
            if (IDS.contains(mapping.getKey().getPath())) {
                mapping.ignore();
            }
        }
    }
}
